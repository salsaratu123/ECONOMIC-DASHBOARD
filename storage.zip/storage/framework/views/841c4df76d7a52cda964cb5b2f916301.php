<div class="card shadow-sm mt-4">

    <div class="card-header">

        📰 Latest News

    </div>

    <div class="card-body">

        <div id="newsList">

            Loading...

        </div>

    </div>

</div><?php /**PATH D:\JOKIAN\economic-dashboard\resources\views/dashboard/news.blade.php ENDPATH**/ ?>