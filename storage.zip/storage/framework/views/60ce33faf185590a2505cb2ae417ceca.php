<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Global Supply Chain Risk Intelligence</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>

</head>

<body>

<div class="wrapper">

    <?php echo $__env->make('dashboard.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main">

        <?php echo $__env->make('dashboard.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="content">

            <?php echo $__env->yieldContent('content'); ?>

        </div>

    </div>

</div>

</body>

</html><?php /**PATH D:\JOKIAN\economic-dashboard\resources\views/layouts/app.blade.php ENDPATH**/ ?>